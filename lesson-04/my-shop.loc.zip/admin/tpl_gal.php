<tr>
	<td>{{id}}</td>
	<td>{{img}}</td>
	<td>{{prod_id}}</td>
</tr>