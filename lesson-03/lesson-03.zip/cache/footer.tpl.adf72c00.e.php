<?php 
/** Fenom template 'footer.tpl' compiled at 2018-05-26 01:02:15 */
return new Fenom\Render($fenom, function ($var, $tpl) {
?>
</body>
</html><?php
}, array(
	'options' => 128,
	'provider' => false,
	'name' => 'footer.tpl',
	'base_name' => 'footer.tpl',
	'time' => 1527285624,
	'depends' => array (
  0 => 
  array (
    'footer.tpl' => 1527285624,
  ),
),
	'macros' => array(),

        ));
