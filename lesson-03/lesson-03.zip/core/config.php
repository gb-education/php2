<?
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','gallery_db');


const galley_dir = "gallery_img/";
const galley_tmp = "gallery_img_cache/";

const max_file_upload = 2048000;

const crop_img_width = 150;
const crop_img_height = 150;

const upload_file_type = "jpg,jpeg,png";