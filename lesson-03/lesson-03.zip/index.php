<? 
require_once ('core/core.php');

PageBuilder($_GET);